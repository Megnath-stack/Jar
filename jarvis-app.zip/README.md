# JARVIS

A voice assistant web app that installs on your phone. Brain: Claude (Anthropic API). Voice: ElevenLabs.

## Push to GitHub
```bash
cd jarvis-app
git init
git add .
git commit -m "Initial JARVIS app"
git branch -M main
git remote add origin https://github.com/<your-username>/jarvis.git
git push -u origin main
```

## Host it free with GitHub Pages
Repo > Settings > Pages > Source: `main` branch, `/ (root)` > Save.
Your app will be at `https://<your-username>.github.io/jarvis/`.

## Install on your phone
Open that URL in Safari (iPhone) or Chrome (Android) > Share/menu > **Add to Home Screen**.

## First-time setup (in-app Settings)
1. Anthropic API key (console.anthropic.com)
2. ElevenLabs API key + a Voice ID (elevenlabs.io)
3. Edit the training text to change Jarvis's personality

## Security note
Keys are stored only in your phone's browser and sent directly to Anthropic and ElevenLabs.
Never commit keys to the repo. For sharing the app with others, put the keys behind a small
server or proxy (Cloudflare Worker, Vercel function) instead of entering them in the browser.
